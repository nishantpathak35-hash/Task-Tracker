import { createFileRoute, notFound, useNavigate } from "@tanstack/react-router";
import { queryOptions, useMutation, useQuery, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { format, parseISO } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PriorityBadge, type Priority } from "@/components/priority-badge";
import { StatusBadge, type Status } from "@/components/status-badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { addComment, deleteTask, toggleChecklistItem, updateTask } from "@/lib/tasks.functions";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";

const taskQuery = (id: string) =>
  queryOptions({
    queryKey: ["tasks", id],
    queryFn: async () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const sb = supabase as any;
      const { data: task } = await sb.from("tasks").select("*").eq("id", id).maybeSingle();
      if (!task) throw notFound();
      const [{ data: checklist }, { data: comments }, { data: activity }] = await Promise.all([
        sb.from("task_checklist_items").select("*").eq("task_id", id).order("sort_order"),
        sb.from("task_comments").select("*").eq("task_id", id).order("created_at"),
        sb.from("task_activity").select("*").eq("task_id", id).order("created_at", { ascending: false }).limit(20),
      ]);
      return { task, checklist: checklist ?? [], comments: comments ?? [], activity: activity ?? [] };
    },
  });

export const Route = createFileRoute("/_authenticated/tasks/$taskId")({
  loader: ({ context, params }) => context.queryClient.ensureQueryData(taskQuery(params.taskId)),
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData ? `${loaderData.task.title} — TaskOps` : "Task — TaskOps" }],
  }),
  component: TaskDetail,
  notFoundComponent: () => <div className="p-8 text-center text-muted-foreground">Task not found.</div>,
  errorComponent: ({ error }) => (
    <div className="p-8 text-center text-destructive">Failed to load task: {error.message}</div>
  ),
});

function TaskDetail() {
  const { taskId } = Route.useParams();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data } = useSuspenseQuery(taskQuery(taskId));
  const update = useServerFn(updateTask);
  const del = useServerFn(deleteTask);
  const toggle = useServerFn(toggleChecklistItem);
  const comment = useServerFn(addComment);
  const [body, setBody] = useState("");

  const { data: members = [] } = useQuery<{ id: string; full_name: string | null }[]>({
    queryKey: ["org-members"],
    queryFn: async () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data } = await (supabase as any).from("profiles").select("id,full_name").order("full_name");
      return data ?? [];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel(`task-${taskId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "task_comments", filter: `task_id=eq.${taskId}` }, () =>
        qc.invalidateQueries({ queryKey: ["tasks", taskId] }),
      )
      .on("postgres_changes", { event: "*", schema: "public", table: "tasks", filter: `id=eq.${taskId}` }, () =>
        qc.invalidateQueries({ queryKey: ["tasks", taskId] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [taskId, qc]);

  const t = data.task;

  const mutStatus = useMutation({
    mutationFn: (status: Status) => update({ data: { id: taskId, patch: { status } } }),
    onSuccess: () => {
      toast.success("Status updated");
      qc.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: (e: Error) => toast.error("Update failed", { description: e.message }),
  });

  const mutAssignee = useMutation({
    mutationFn: (assigned_to: string) => update({ data: { id: taskId, patch: { assigned_to } } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tasks"] }),
  });

  return (
    <div className="p-6 max-w-5xl mx-auto grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <PriorityBadge value={t.priority as Priority} />
              <StatusBadge value={t.status as Status} />
            </div>
            <h1 className="font-display text-2xl font-semibold">{t.title}</h1>
            {t.description && <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{t.description}</p>}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={async () => {
              if (!confirm("Delete this task?")) return;
              await del({ data: { id: taskId } });
              toast.success("Task deleted");
              qc.invalidateQueries({ queryKey: ["tasks"] });
              navigate({ to: "/my-work" });
            }}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        {data.checklist.length > 0 && (
          <Card>
            <CardHeader className="pb-2"><CardTitle>Checklist</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {data.checklist.map((c: { id: string; label: string; is_mandatory: boolean; done: boolean }) => (
                <label key={c.id} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={c.done}
                    onCheckedChange={async (v) => {
                      await toggle({ data: { id: c.id, done: !!v } });
                      qc.invalidateQueries({ queryKey: ["tasks", taskId] });
                    }}
                  />
                  <span className={c.done ? "line-through text-muted-foreground" : ""}>{c.label}</span>
                  {c.is_mandatory && <span className="text-[10px] text-muted-foreground ml-1">required</span>}
                </label>
              ))}
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="pb-2"><CardTitle>Comments</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {data.comments.length === 0 && <p className="text-sm text-muted-foreground">No comments yet.</p>}
            {data.comments.map((c: { id: string; body: string; author_id: string; created_at: string }) => (
              <div key={c.id} className="flex gap-2">
                <Avatar className="h-7 w-7"><AvatarFallback className="text-[10px]">{c.author_id.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 bg-muted/40 rounded-md p-2">
                  <div className="text-xs text-muted-foreground mb-0.5">{format(parseISO(c.created_at), "MMM d, HH:mm")}</div>
                  <div className="text-sm whitespace-pre-wrap">{c.body}</div>
                </div>
              </div>
            ))}
            <div className="flex gap-2 pt-2">
              <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Add a comment…" rows={2} />
              <Button
                disabled={!body.trim()}
                onClick={async () => {
                  await comment({ data: { task_id: taskId, body: body.trim() } });
                  setBody("");
                }}
              >
                Post
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Details</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div>
              <div className="text-xs text-muted-foreground mb-1">Status</div>
              <Select value={t.status} onValueChange={(v) => mutStatus.mutate(v as Status)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in_progress">In progress</SelectItem>
                  <SelectItem value="waiting_review">Waiting review</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">Assignee</div>
              <Select value={t.assigned_to ?? ""} onValueChange={(v) => mutAssignee.mutate(v)}>
                <SelectTrigger><SelectValue placeholder="Unassigned" /></SelectTrigger>
                <SelectContent>
                  {members.map((m) => (
                    <SelectItem key={m.id} value={m.id}>{m.full_name || m.id.slice(0, 6)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Due</span>
              <span>{t.due_date ? format(parseISO(t.due_date), "MMM d, yyyy") : "—"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Est. hours</span>
              <span>{t.expected_hours ?? "—"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Created</span>
              <span>{format(parseISO(t.created_at), "MMM d")}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Activity</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-xs">
            {data.activity.length === 0 && <p className="text-muted-foreground">No activity yet.</p>}
            {data.activity.map((a: { id: string; event: string; created_at: string }) => (
              <div key={a.id} className="flex justify-between">
                <span>{a.event}</span>
                <span className="text-muted-foreground">{format(parseISO(a.created_at), "MMM d, HH:mm")}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

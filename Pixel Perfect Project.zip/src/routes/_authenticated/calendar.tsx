import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { addMonths, endOfMonth, format, isSameDay, isSameMonth, parseISO, startOfMonth, startOfWeek, addDays, isPast } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

const monthQuery = queryOptions({
  queryKey: ["tasks", "calendar"],
  queryFn: async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data } = await (supabase as any)
      .from("tasks")
      .select("id,title,priority,status,due_date")
      .not("due_date", "is", null)
      .limit(1000);
    return data ?? [];
  },
});

export const Route = createFileRoute("/_authenticated/calendar")({
  loader: ({ context }) => context.queryClient.ensureQueryData(monthQuery),
  head: () => ({ meta: [{ title: "Calendar — TaskOps" }] }),
  component: CalendarPage,
});

function CalendarPage() {
  const { data } = useSuspenseQuery(monthQuery);
  const [cursor, setCursor] = useState(new Date());
  const monthStart = startOfMonth(cursor);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const days = Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Calendar</h1>
          <p className="text-sm text-muted-foreground">Tasks and compliance deadlines by due date.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setCursor((c) => addMonths(c, -1))}><ChevronLeft className="h-4 w-4" /></Button>
          <div className="min-w-40 text-center font-medium">{format(cursor, "MMMM yyyy")}</div>
          <Button variant="outline" size="icon" onClick={() => setCursor((c) => addMonths(c, 1))}><ChevronRight className="h-4 w-4" /></Button>
          <Button variant="ghost" size="sm" onClick={() => setCursor(new Date())}>Today</Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-2">
          <div className="grid grid-cols-7 text-xs font-medium text-muted-foreground border-b">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
              <div key={d} className="p-2">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-px bg-border">
            {days.map((d) => {
              const items = data.filter((t: { due_date: string }) => t.due_date && isSameDay(parseISO(t.due_date), d));
              const isCurrentMonth = isSameMonth(d, cursor);
              const today = isSameDay(d, new Date());
              return (
                <div
                  key={d.toISOString()}
                  className={cn(
                    "bg-card min-h-[110px] p-1.5",
                    !isCurrentMonth && "opacity-40",
                  )}
                >
                  <div className={cn("text-xs font-medium mb-1", today && "text-primary")}>{format(d, "d")}</div>
                  <div className="space-y-1">
                    {items.slice(0, 3).map((t: { id: string; title: string; due_date: string; status: string; priority: string }) => (
                      <Link
                        key={t.id}
                        to="/tasks/$taskId"
                        params={{ taskId: t.id }}
                        className={cn(
                          "block text-[11px] px-1.5 py-0.5 rounded truncate",
                          t.status === "overdue" || (isPast(parseISO(t.due_date)) && !["completed", "approved", "cancelled"].includes(t.status))
                            ? "bg-destructive/10 text-destructive"
                            : "bg-primary/10 text-primary",
                        )}
                      >
                        {t.title}
                      </Link>
                    ))}
                    {items.length > 3 && <div className="text-[10px] text-muted-foreground">+{items.length - 3} more</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
      <p className="text-xs text-muted-foreground">Month grid • {format(monthStart, "MMM d")} – {format(endOfMonth(cursor), "MMM d")}</p>
    </div>
  );
}

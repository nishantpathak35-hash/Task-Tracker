import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useMe } from "@/hooks/use-me";

const adminQuery = queryOptions({
  queryKey: ["admin", "overview"],
  queryFn: async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = supabase as any;
    const [{ data: members }, { data: departments }, { data: roles }] = await Promise.all([
      sb.from("profiles").select("id,full_name,designation,department_id"),
      sb.from("departments").select("id,name,manager_id"),
      sb.from("user_roles").select("user_id,role"),
    ]);
    return { members: members ?? [], departments: departments ?? [], roles: roles ?? [] };
  },
});

export const Route = createFileRoute("/_authenticated/admin")({
  loader: ({ context }) => context.queryClient.ensureQueryData(adminQuery),
  head: () => ({ meta: [{ title: "Admin — TaskOps" }] }),
  component: AdminPage,
});

function AdminPage() {
  const { data } = useSuspenseQuery(adminQuery);
  const { data: me } = useMe();
  const isAdmin = me?.roles.includes("super_admin");

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold">Admin</h1>
        <p className="text-sm text-muted-foreground">Workspace, people, and departments.</p>
      </div>

      {!isAdmin && <p className="text-sm text-muted-foreground">You need super admin access to change these settings.</p>}

      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle>Departments</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {data.departments.map((d: { id: string; name: string; manager_id: string | null }) => (
              <div key={d.id} className="flex items-center justify-between border rounded-md p-2 text-sm">
                <span className="font-medium">{d.name}</span>
                <span className="text-xs text-muted-foreground">manager: {d.manager_id ? d.manager_id.slice(0, 6) : "—"}</span>
              </div>
            ))}
            {data.departments.length === 0 && <p className="text-sm text-muted-foreground">No departments.</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle>People</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {data.members.map((m: { id: string; full_name: string | null; designation: string | null }) => {
              const roles = data.roles.filter((r: { user_id: string; role: string }) => r.user_id === m.id).map((r: { role: string }) => r.role);
              return (
                <div key={m.id} className="flex items-center justify-between border rounded-md p-2 text-sm">
                  <div>
                    <div className="font-medium">{m.full_name || m.id.slice(0, 6)}</div>
                    {m.designation && <div className="text-xs text-muted-foreground">{m.designation}</div>}
                  </div>
                  <div className="flex gap-1">
                    {roles.map((r: string) => (
                      <Badge key={r} variant="secondary" className="text-[10px]">{r.replace("_", " ")}</Badge>
                    ))}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TaskList, type TaskRow } from "@/components/task-list";
import { PriorityBadge, type Priority } from "@/components/priority-badge";
import { StatusBadge, type Status } from "@/components/status-badge";
import { Link } from "@tanstack/react-router";

const tasksQuery = queryOptions({
  queryKey: ["tasks", "all"],
  queryFn: async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data } = await (supabase as any)
      .from("tasks")
      .select("id,title,priority,status,due_date,assigned_to,expected_hours")
      .order("due_date", { ascending: true, nullsFirst: false })
      .limit(500);
    return (data ?? []) as TaskRow[];
  },
});

export const Route = createFileRoute("/_authenticated/my-work")({
  loader: ({ context }) => context.queryClient.ensureQueryData(tasksQuery),
  head: () => ({ meta: [{ title: "My Work — TaskOps" }] }),
  component: MyWork,
});

function MyWork() {
  const { data: all } = useSuspenseQuery(tasksQuery);
  const [q, setQ] = useState("");
  const [priority, setPriority] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");

  const filtered = all.filter((t) => {
    if (q && !t.title.toLowerCase().includes(q.toLowerCase())) return false;
    if (priority !== "all" && t.priority !== priority) return false;
    if (status !== "all" && t.status !== status) return false;
    return true;
  });

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">My Work</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} of {all.length} tasks</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search tasks…" className="max-w-xs" />
        <Select value={priority} onValueChange={setPriority}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priorities</SelectItem>
            <SelectItem value="blocker">Blocker</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="assigned">Assigned</SelectItem>
            <SelectItem value="in_progress">In progress</SelectItem>
            <SelectItem value="waiting_review">Waiting review</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="list">
        <TabsList>
          <TabsTrigger value="list">List</TabsTrigger>
          <TabsTrigger value="board">Board</TabsTrigger>
        </TabsList>
        <TabsContent value="list">
          <Card>
            <CardContent className="p-0">
              <TaskList tasks={filtered} empty="No tasks match your filters." />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="board">
          <Board tasks={filtered} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

const columns: { key: Status; label: string }[] = [
  { key: "assigned", label: "Assigned" },
  { key: "in_progress", label: "In progress" },
  { key: "waiting_review", label: "Waiting review" },
  { key: "overdue", label: "Overdue" },
  { key: "completed", label: "Completed" },
];

function Board({ tasks }: { tasks: TaskRow[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 mt-3">
      {columns.map((c) => {
        const items = tasks.filter((t) => t.status === c.key);
        return (
          <div key={c.key} className="bg-muted/40 rounded-lg p-2 min-h-[300px]">
            <div className="flex items-center justify-between px-2 py-1 text-xs font-medium">
              <span>{c.label}</span>
              <span className="text-muted-foreground">{items.length}</span>
            </div>
            <div className="space-y-2 mt-1">
              {items.map((t) => (
                <Link key={t.id} to="/tasks/$taskId" params={{ taskId: t.id }} className="block bg-card rounded-md p-3 shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-elevated)] transition-shadow">
                  <div className="text-sm font-medium leading-tight">{t.title}</div>
                  <div className="mt-2 flex items-center gap-2">
                    <PriorityBadge value={t.priority as Priority} />
                    <StatusBadge value={t.status} />
                  </div>
                </Link>
              ))}
              {items.length === 0 && <div className="px-2 py-4 text-xs text-muted-foreground">Empty</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
